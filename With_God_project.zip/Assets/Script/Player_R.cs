﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_R : PlayerFSMState {
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }


    // Update is called once per frame

}
